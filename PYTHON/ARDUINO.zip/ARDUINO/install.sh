sudoapt-get install apache2 libapache2-mod-wsgi  libapache2-mod-python
sudo apt-get install python-flask
