<?php 
interface ICrugeClient {

	public function doLogin();
	
	public function doCallback();

} 
